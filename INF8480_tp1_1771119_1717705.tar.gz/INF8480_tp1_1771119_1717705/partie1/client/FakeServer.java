package ca.polymtl.inf8480.tp1.client;

public class FakeServer {
	byte[] execute(byte[] data) {
		return data;
	}
}
